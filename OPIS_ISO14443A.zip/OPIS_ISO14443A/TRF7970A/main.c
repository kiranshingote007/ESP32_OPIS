
/* Includeing header files */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>
#include "freertos/FreeRTOS.h"
#include "freertos/FreeRTOSConfig.h"
#include "freertos/task.h"
#include "esp_system.h"
#include "driver/spi_master.h"
#include "driver/gpio.h"
#include "esp_log.h"

#include "iso14443a.h"
#include "trf797x.h"
#include "spi.h"


#define SWITCH          GPIO_NUM_0                          // Switch input
#define S3_RED_LED      GPIO_NUM_26                         // S3 Red LED feedback input
#define S4_GREEN_LED    GPIO_NUM_25                         // S4 Green LED feedback input

#define RELAY_1         GPIO_NUM_15                         // Relay 1 output
#define RELAY_IGN       GPIO_NUM_16                         // Ignition Relay 2 output
#define RELAY_RED_LED   GPIO_NUM_13                         // Red LED Relay 3 output
#define RELAY_GRN_LED   GPIO_NUM_14                         // Green LED Relay 4 output
#define BLUE_LED        GPIO_NUM_21                         // Blue LED output
#define RED_LED         GPIO_NUM_22                         // Red LED output


#define SPI_TAG "TRF7970A Communication"

uint8_t buf[300];

uint8_t enable = 0;

uint8_t i_reg = 0x01;							// interrupt register

uint8_t irq_flag = 0x00;
uint8_t rx_error_flag = 0x00;
uint8_t rxtx_state = 1;							// used for transmit recieve byte count

int16_t nfc_state;

uint8_t remote_flag = 0;
uint8_t stand_alone_flag = 1;
uint8_t reader_mode = 0x00;	


int app_main(void)
{
    //Ininitalising SPI peripheral
    vSpiInit();

    // Setting initial state of outputs
    gpio_set_direction(S3_RED_LED, GPIO_MODE_OUTPUT);
    gpio_set_level(S3_RED_LED, 0);
    gpio_set_direction(S4_GREEN_LED, GPIO_MODE_OUTPUT);
    gpio_set_level(S4_GREEN_LED, 0);
    
    gpio_set_direction(RELAY_1, GPIO_MODE_OUTPUT);
    gpio_set_level(RELAY_1, 0);
    gpio_set_direction(RELAY_IGN, GPIO_MODE_OUTPUT);
    gpio_set_level(RELAY_IGN, 0);
    gpio_set_direction(RELAY_RED_LED, GPIO_MODE_OUTPUT);
    gpio_set_level(RELAY_RED_LED, 0);
    gpio_set_direction(RELAY_GRN_LED, GPIO_MODE_OUTPUT);
    gpio_set_level(RELAY_GRN_LED, 0);

    gpio_set_direction(BLUE_LED, GPIO_MODE_OUTPUT);
    gpio_set_level(BLUE_LED, 0);
    gpio_set_direction(RED_LED, GPIO_MODE_OUTPUT);
    gpio_set_level(RED_LED, 0);

/*  gpio_set_level(RF_ENABLE, 0);

    gpio_set_level(RF_ENABLE, 0);
    vTaskDelay(1 / configTICK_RATE_HZ);     // wait until system clock started
    gpio_set_level(RF_ENABLE, 1);
    vTaskDelay(1 / configTICK_RATE_HZ);     // wait  
*/
   Trf797xInitialSettings();

    while(1)
    {
//        Iso14443aFindTag();
    }
}
