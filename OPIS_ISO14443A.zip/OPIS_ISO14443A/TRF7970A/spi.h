#include "esp_err.h"

/* Declaring the funtions which are used in the program */
void vSpiInit(void);
void spi_read_data(uint8_t addr);
void spi_write_data(uint8_t addr, uint8_t data);
esp_err_t send_spi_command(uint8_t command);