# RFID_RC522_ESP-IDF
This library provides everything for interfacing with the MIFARE cards.
You can check this video to see how to use it : https://youtu.be/0Aga1kvU2Dw


Make sure you follow the following sequence when writing/reading from the card : 

![Screenshot 2024-08-24 111505](https://github.com/user-attachments/assets/ac5ecd52-7650-4427-8c0a-2b7d353c420e)

I am not responsible for any damage to your MIFARE card .
