#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "driver/spi_master.h"
#include "freertos/freeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "MFRC522.h"
#include "esp_log.h"

char username[16] = {0};
char password[16] = {0};

uint8_t card_rx_buffer[20];
uint8_t card_rx_len = 20;

MIFARE_Key key = 
{
 .keyByte = {0xff,0xff,0xff,0xff,0xff,0xff}
};
uint8_t req_buffer[16];
uint8_t req_len = 16;
uint8_t status = 0;

void app_main(void)
{
    esp_err_t ret;
    spi_device_handle_t spi;
/*
    spi_bus_config_t buscfg={
        .miso_io_num=12,
        .mosi_io_num=13,
        .sclk_io_num=14,
        .quadwp_io_num=-1,
        .quadhd_io_num=-1
    };
    spi_device_interface_config_t devcfg={
        .clock_speed_hz=5000000,               //Clock out at 5 MHz
        .mode=0,                                //SPI mode 0
        .spics_io_num=15,//8                    //CS pin
        .queue_size=7,                          //We want to be able to queue 7 transactions at a time
        //.pre_cb=ili_spi_pre_transfer_callback,  //Specify pre-transfer callback to handle D/C line
    };*/

       spi_bus_config_t buscfg={
        .miso_io_num=19,
        .mosi_io_num=23,
        .sclk_io_num=18,
        .quadwp_io_num=-1,
        .quadhd_io_num=-1
    };
    spi_device_interface_config_t devcfg={
        .clock_speed_hz=5000000,               //Clock out at 5 MHz
        .mode=0,                                //SPI mode 0
        .spics_io_num=5,//8                    //CS pin
        .queue_size=7,                          //We want to be able to queue 7 transactions at a time
        //.pre_cb=ili_spi_pre_transfer_callback,  //Specify pre-transfer callback to handle D/C line
    };

    //Initialize the SPI bus
    ret=spi_bus_initialize(SPI2_HOST, &buscfg, SPI_DMA_CH_AUTO);
    assert(ret==ESP_OK);
    //Attach the RFID to the SPI bus
    ret=spi_bus_add_device(SPI2_HOST, &devcfg, &spi);
    assert(ret==ESP_OK);
   
/*    vTaskDelay(1 / portTICK_PERIOD_MS);    				// wait until system clock started
		
	Trf797xInitialSettings();			// Set MCU Clock Frequency to 6.78 MHz and OOK Modulation
	
	vTaskDelay(10 / portTICK_PERIOD_MS);*/

    PCD_Init(spi);

    while(1)
    {
//        Iso14443aFindTag();

        if(PICC_IsNewCardPresent(spi))                   //Checking for new card
    	{

            printf("***card detected!***\n");
    		GetStatusCodeName(PICC_Select(spi,&uid,0));
    		PICC_DumpToSerial(spi,&uid);                  //DETAILS OF UID ALONG WITH SECTORS
    		vTaskDelay(100 / portTICK_PERIOD_MS);
    	}
    	vTaskDelay(500 / portTICK_PERIOD_MS);
    }
}
