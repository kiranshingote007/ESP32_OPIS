//***************************************************************
//------------<02.Dec.2010 by Peter Reiser>----------------------
//***************************************************************

#ifndef _TYPEDEF_H_
#define _TYPEDEF_H_

//================================================================

typedef unsigned char u08_t;
typedef unsigned short u16_t;
typedef unsigned long u32_t;

typedef signed char s08_t;
typedef signed short s16_t;
typedef signed long s32_t;

//===============================================================

#endif
