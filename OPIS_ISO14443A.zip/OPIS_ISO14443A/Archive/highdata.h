#ifndef _HIGHDATA_H_
#define _HIGHDATA_H_

#include "mcu.h"
#include "trf797x.h"
#include "types.h"

void HighDataCommunication(u08_t *pbuf);

#endif
